This folder includes all code used in the numerical experiments in Sections 
6, 7 and 8 for the paper "Robust optimization for models with uncertain SOC and SDP 
constraints" by Jianzhe Zhen, Frans de Ruiter, Ernst Roos & Dick den Hertog.

